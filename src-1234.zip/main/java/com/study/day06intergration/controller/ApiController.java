package com.study.day06intergration.controller;

import com.study.day06intergration.service.ChatService;
import com.study.day06intergration.service.HelpdeskService;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ApiController {
    private final ChatService chatService;
    private final HelpdeskService helpdeskService;

    public ApiController(ChatService chatService, HelpdeskService helpdeskService) {
        this.chatService = chatService;
        this.helpdeskService = helpdeskService;
    }


}
